## Install neopixel fimata on arduino from here:
###https://github.com/ajfisher/node-pixel/tree/master/firmware
##Download and run 'npm intstall'
## 'node panel.js'
## Open localhost:3000(only works in Chrome and Firefox)
